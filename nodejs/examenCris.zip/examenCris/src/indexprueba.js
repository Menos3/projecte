import 'jquery';
// import { createList } from "./js/nuevoPreparacionExamen"
import { onSubmit, iniciar} from './js/nuevoPreparacionExamen';
import "./bootstrap.min.css";
import "./css/form.css";


// await createList();

await iniciar();
// await creacionForm();
// mostrarFormAsset();



