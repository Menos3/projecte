export class Usuari {

    constructor(id_usuari, username, password, id_role) {

        this.id_usuari = id_usuari;
        this.username = username;
        this.password = password;
        this.id_role = id_role;
    }
}