import React from 'react'
import Chatapp from './chatapp/Chatapp'
import { Chats } from './chatapp/CrearChats'
// import ListaActores from './Ejercicio1/ListaActores'
import ListTickets from './proyecte/ListTickets'

const Body = () => {
  return (
    <>
      {/* <ListaActores /> */}
      {/* {<ListTickets />} */}
      
      {/*Lista Chat*/}
      <Chatapp/>
    </>
  )
}

export default Body