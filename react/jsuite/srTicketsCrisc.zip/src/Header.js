import React from 'react'

const Header = () => {
  return (
    <>
    <div>JSuite</div>
    <br></br>
    </>
  )
}

export default Header