import React from 'react'

export const Chats = () => {
  return (
    <div>Chats</div>
  )
}
