import React from 'react'
import PropTypes from 'prop-types'

function Pantalla({ value}) {
  return (
    <div>{ value}</div>
  )
}

Pantalla.propTypes = {}

export default Pantalla
