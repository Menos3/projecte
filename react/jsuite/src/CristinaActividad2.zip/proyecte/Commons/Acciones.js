import React from 'react'
// import PropTypes from 'prop-types'

function Acciones(props) {
  return (
    <div>Acciones</div>
  )
}

// Acciones.propTypes = {}

export default Acciones
