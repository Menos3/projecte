import React from 'react'
import ListaActores from '../../Ejercicio1/ListaActores'
import ListTickets from '../ListTickets'
import Acciones from './Acciones'
import Navegacion from './Navegacion'
import Calculadora from '../../Ejericio2/Calculadora'

const Body = () => {
  return (
    <>Body
      {/* <ListaActores/> */}
      {/* <Navegacion/> */}
      {/* <Acciones /> */}
      <Calculadora/>
      {/* <ListTickets/> */}

    </>
  )
}

export default Body