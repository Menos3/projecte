import React from 'react'
// import PropTypes from 'prop-types'
import Iconos from './Iconos'

function Navegacion(props) {
    return (
      
        <>
            <p>Barra de navegacion</p>
            <Iconos />
            <Iconos />
            <Iconos />
        </>
  )
}

// Navegacion.propTypes = {}

export default Navegacion
