import React from 'react'

const Chatapp = () => {
  return (
    <div>Chatapp</div>
  )
}

export default Chatapp