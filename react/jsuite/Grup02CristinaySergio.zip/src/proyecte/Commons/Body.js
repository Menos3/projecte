import React from 'react'

import ListTickets from '../ListTickets'
import Acciones from './Acciones'
import Navegacion from './Navegacion'


const Body = () => {
  return (
    <>
      {/* <ListaActores/> */}
      {/* <Navegacion/> */}
      {/* <Acciones /> */}
      {/* <Calculadora/> */}
      {/* <ListTickets/> */}

    </>
  )
}

export default Body