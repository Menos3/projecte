import React from 'react'

const Footer = () => {
  return (
    <>
    <br></br>
    <div>GRUP 02</div>
    </>
  )
}

export default Footer