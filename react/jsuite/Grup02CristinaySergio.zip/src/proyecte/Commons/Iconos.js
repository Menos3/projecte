import React from 'react'
// import PropTypes from 'prop-types'

function Iconos(props) {
  return (
      <>
        <div>Iconos</div>
      </>
  )
}

// Iconos.propTypes = {}

export default Iconos
