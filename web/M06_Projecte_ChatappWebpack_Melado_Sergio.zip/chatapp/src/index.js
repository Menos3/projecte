import {saludar} from './js/components'
import "./styles.css";

const nom = "Sergio"
saludar(nom);